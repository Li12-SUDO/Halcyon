const cloud = require("wx-server-sdk");

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

const db = cloud.database();
const command = db.command;

const COLLECTIONS = {
  ledger: "ledger_records",
  todos: "todos",
  health: "health_records",
  anniversaries: "anniversaries",
  quoteFavorites: "quote_favorites",
  settings: "user_settings"
};

const COLLECTION_NAMES = Object.keys(COLLECTIONS).map((key) => COLLECTIONS[key]);
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const TIME_PATTERN = /^\d{2}:\d{2}$/;

function success(data) {
  return { success: true, data };
}

function failure(code, message) {
  return { success: false, code, message };
}

function text(value, maxLength) {
  return String(value == null ? "" : value).trim().slice(0, maxLength);
}

function number(value, min, max) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < min || parsed > max) return null;
  return parsed;
}

function validDate(value) {
  const normalized = text(value, 10);
  return DATE_PATTERN.test(normalized) ? normalized : "";
}

function validTime(value) {
  const normalized = text(value, 5);
  return TIME_PATTERN.test(normalized) ? normalized : "";
}

function sanitize(entity, input) {
  const data = input || {};

  if (entity === "ledger") {
    const type = data.type === "income" ? "income" : "expense";
    const amount = number(data.amount, 0.01, 99999999.99);
    const date = validDate(data.date);
    const time = validTime(data.time);
    const category = text(data.category, 20);
    if (amount === null || !date || !time || !category) {
      throw new Error("INVALID_LEDGER_RECORD");
    }
    return { type, amount, category, note: text(data.note, 200), date, time };
  }

  if (entity === "todos") {
    const title = text(data.title, 80);
    const date = validDate(data.date);
    const priorities = ["低", "中", "高"];
    if (!title || !date) throw new Error("INVALID_TODO");
    return {
      title,
      date,
      priority: priorities.includes(data.priority) ? data.priority : "中",
      done: Boolean(data.done)
    };
  }

  if (entity === "health") {
    const weight = number(data.weight, 20, 500);
    const bodyFat = data.bodyFat === "" || data.bodyFat == null
      ? null
      : number(data.bodyFat, 1, 80);
    const date = validDate(data.date);
    if (weight === null || bodyFat === null && data.bodyFat !== "" && data.bodyFat != null || !date) {
      throw new Error("INVALID_HEALTH_RECORD");
    }
    return { weight, bodyFat, date };
  }

  if (entity === "anniversaries") {
    const name = text(data.name, 30);
    const date = validDate(data.date);
    if (!name || !date) throw new Error("INVALID_ANNIVERSARY");
    return { name, date, memo: text(data.memo, 100) };
  }

  if (entity === "settings") {
    return { sync: data.sync !== false };
  }

  if (entity === "quoteFavorites") {
    const content = text(data.content, 300);
    if (!content) throw new Error("INVALID_QUOTE");
    return {
      content,
      author: text(data.author, 60),
      category: text(data.category, 20) || "收藏",
      tone: text(data.tone, 20) || "yellow"
    };
  }

  throw new Error("UNKNOWN_ENTITY");
}

function entityCollection(entity) {
  const name = COLLECTIONS[entity];
  if (!name) throw new Error("UNKNOWN_ENTITY");
  return db.collection(name);
}

async function ensureCollections() {
  const results = [];
  for (const name of COLLECTION_NAMES) {
    try {
      await db.createCollection(name);
      results.push({ name, created: true });
    } catch (error) {
      const message = String(error && (error.errMsg || error.message) || error);
      if (!/exist|already|存在|-502005/i.test(message)) throw error;
      results.push({ name, created: false });
    }
  }
  return results;
}

function buildOwnedWhere(openid, filters) {
  const where = { _openid: openid };
  const startDate = validDate(filters && filters.startDate);
  const endDate = validDate(filters && filters.endDate);
  const exactDate = validDate(filters && filters.date);

  if (exactDate) where.date = exactDate;
  else if (startDate && endDate) where.date = command.gte(startDate).and(command.lte(endDate));
  else if (startDate) where.date = command.gte(startDate);
  else if (endDate) where.date = command.lte(endDate);

  return where;
}

async function listOwned(entity, openid, filters, page, pageSize) {
  const collection = entityCollection(entity);
  const where = buildOwnedWhere(openid, filters || {});
  const size = Math.max(1, Math.min(Number(pageSize) || 100, 100));
  const currentPage = Math.max(0, Number(page) || 0);
  let query = collection.where(where);

  if (entity === "quoteFavorites" || entity === "settings") {
    query = query.orderBy("createdAt", "desc");
  } else {
    query = query.orderBy("date", "desc").orderBy("createdAt", "desc");
  }

  const [records, countResult] = await Promise.all([
    query.skip(currentPage * size).limit(size).get(),
    collection.where(where).count()
  ]);

  return {
    items: records.data,
    total: countResult.total,
    hasMore: (currentPage + 1) * size < countResult.total
  };
}

async function getOwned(entity, openid, id) {
  const recordId = text(id, 80);
  if (!recordId) throw new Error("MISSING_ID");
  const result = await entityCollection(entity).where({ _id: recordId, _openid: openid }).limit(1).get();
  return result.data[0] || null;
}

async function saveOwned(entity, openid, id, input) {
  const collection = entityCollection(entity);
  const payload = sanitize(entity, input);
  const recordId = text(id, 80);
  const now = db.serverDate();

  if (recordId) {
    const current = await getOwned(entity, openid, recordId);
    if (!current) throw new Error("NOT_FOUND");
    await collection.doc(recordId).update({ data: Object.assign({}, payload, { updatedAt: now }) });
    return { id: recordId, updated: true };
  }

  if (entity === "health") {
    const existing = await collection.where({ _openid: openid, date: payload.date }).limit(1).get();
    if (existing.data.length) {
      const existingId = existing.data[0]._id;
      await collection.doc(existingId).update({ data: Object.assign({}, payload, { updatedAt: now }) });
      return { id: existingId, updated: true };
    }
  }

  if (entity === "settings") {
    const existing = await collection.where({ _openid: openid }).limit(1).get();
    if (existing.data.length) {
      const existingId = existing.data[0]._id;
      await collection.doc(existingId).update({ data: Object.assign({}, payload, { updatedAt: now }) });
      return { id: existingId, updated: true };
    }
  }

  const result = await collection.add({
    data: Object.assign({}, payload, {
      _openid: openid,
      createdAt: now,
      updatedAt: now
    })
  });
  return { id: result._id, updated: false };
}

async function removeOwned(entity, openid, id) {
  const recordId = text(id, 80);
  if (!recordId) throw new Error("MISSING_ID");
  const result = await entityCollection(entity).where({ _id: recordId, _openid: openid }).remove();
  return { removed: result.stats.removed };
}

async function fetchAllOwned(entity, openid, filters) {
  const first = await listOwned(entity, openid, filters, 0, 100);
  const items = first.items.slice();
  let page = 1;
  while (items.length < first.total && page < 10) {
    const next = await listOwned(entity, openid, filters, page, 100);
    items.push.apply(items, next.items);
    page += 1;
  }
  return items;
}

async function dashboard(openid, today) {
  const safeToday = validDate(today);
  if (!safeToday) throw new Error("INVALID_DATE");
  const monthStart = safeToday.slice(0, 7) + "-01";
  const monthEnd = safeToday.slice(0, 7) + "-31";

  const [monthLedger, todayTodos, healthToday, anniversaries, ledgerCount, todoDoneCount] = await Promise.all([
    fetchAllOwned("ledger", openid, { startDate: monthStart, endDate: monthEnd }),
    fetchAllOwned("todos", openid, { date: safeToday }),
    fetchAllOwned("health", openid, { date: safeToday }),
    fetchAllOwned("anniversaries", openid, {}),
    entityCollection("ledger").where({ _openid: openid }).count(),
    entityCollection("todos").where({ _openid: openid, done: true }).count()
  ]);

  let monthExpense = 0;
  let monthIncome = 0;
  let todayExpense = 0;
  let todayIncome = 0;
  const ledgerDates = new Set();

  monthLedger.forEach((record) => {
    const amount = Number(record.amount) || 0;
    ledgerDates.add(record.date);
    if (record.type === "income") monthIncome += amount;
    else monthExpense += amount;
    if (record.date === safeToday) {
      if (record.type === "income") todayIncome += amount;
      else todayExpense += amount;
    }
  });

  return {
    monthExpense,
    monthIncome,
    todayExpense,
    todayIncome,
    todoTodayTotal: todayTodos.length,
    todoTodayDone: todayTodos.filter((item) => item.done).length,
    healthRecordedToday: healthToday.length > 0,
    latestAnniversary: anniversaries[0] || null,
    stats: {
      ledgerDays: ledgerDates.size,
      ledgerRecords: ledgerCount.total,
      todoDone: todoDoneCount.total,
      anniversaries: anniversaries.length
    }
  };
}

async function toggleFavorite(openid, quote) {
  const payload = sanitize("quoteFavorites", quote);
  const collection = entityCollection("quoteFavorites");
  const existing = await collection.where({ _openid: openid, content: payload.content }).limit(1).get();
  if (existing.data.length) {
    await collection.doc(existing.data[0]._id).remove();
    return { favorited: false, id: "" };
  }
  const result = await collection.add({
    data: Object.assign({}, payload, {
      _openid: openid,
      createdAt: db.serverDate(),
      updatedAt: db.serverDate()
    })
  });
  return { favorited: true, id: result._id };
}

async function favoriteStatus(openid, content) {
  const normalized = text(content, 300);
  if (!normalized) return { favorited: false, id: "" };
  const result = await entityCollection("quoteFavorites")
    .where({ _openid: openid, content: normalized })
    .limit(1)
    .get();
  return {
    favorited: result.data.length > 0,
    id: result.data.length ? result.data[0]._id : ""
  };
}

async function clearAll(openid) {
  const removed = {};
  for (const entity of Object.keys(COLLECTIONS)) {
    const collection = entityCollection(entity);
    let total = 0;
    while (true) {
      const records = await collection.where({ _openid: openid }).field({ _id: true }).limit(100).get();
      if (!records.data.length) break;
      const ids = records.data.map((record) => record._id);
      const result = await collection.where({ _openid: openid, _id: command.in(ids) }).remove();
      total += result.stats.removed;
      if (!result.stats.removed) throw new Error("DELETE_FAILED");
    }
    removed[entity] = total;
  }
  return removed;
}

exports.main = async (event) => {
  const context = cloud.getWXContext();
  const openid = context.OPENID;
  if (!openid) return failure("UNAUTHORIZED", "无法识别当前微信用户");

  try {
    const action = event && event.action;
    if (action === "bootstrap") return success(await ensureCollections());
    if (action === "list") {
      return success(await listOwned(event.entity, openid, event.filters, event.page, event.pageSize));
    }
    if (action === "get") return success(await getOwned(event.entity, openid, event.id));
    if (action === "save") return success(await saveOwned(event.entity, openid, event.id, event.data));
    if (action === "remove") return success(await removeOwned(event.entity, openid, event.id));
    if (action === "dashboard") return success(await dashboard(openid, event.today));
    if (action === "toggleFavorite") return success(await toggleFavorite(openid, event.data));
    if (action === "favoriteStatus") return success(await favoriteStatus(openid, event.content));
    if (action === "clearAll") return success(await clearAll(openid));
    return failure("UNKNOWN_ACTION", "不支持的数据操作");
  } catch (error) {
    console.error("halcyonData", event && event.action, error);
    const messageMap = {
      INVALID_LEDGER_RECORD: "账目数据不完整",
      INVALID_TODO: "待办数据不完整",
      INVALID_HEALTH_RECORD: "健康数据格式不正确",
      INVALID_ANNIVERSARY: "纪念日数据不完整",
      INVALID_DATE: "日期格式不正确",
      NOT_FOUND: "记录不存在或已删除",
      UNKNOWN_ENTITY: "不支持的数据类型",
      MISSING_ID: "缺少记录 ID"
    };
    const code = error && error.message || "SERVER_ERROR";
    return failure(code, messageMap[code] || "云端数据操作失败");
  }
};
