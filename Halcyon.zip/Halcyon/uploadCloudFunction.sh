${installPath} cloud functions deploy --e cloudbase-d6ge5nbgu9081b7cf --n halcyonData --r --project ${projectPath}
