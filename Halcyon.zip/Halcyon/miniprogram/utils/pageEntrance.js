function playPageEntrance(page) {
  const previousVariant = page.data.pageEnterVariant;
  const nextVariant = previousVariant === "a" ? "b" : "a";
  const sequence = (page.pageEntranceSequence || 0) + 1;
  page.pageEntranceSequence = sequence;

  page.setData({ pageEnterVariant: "" }, () => {
    const start = () => {
      if (page.pageEntranceSequence !== sequence) return;
      page.setData({ pageEnterVariant: nextVariant });
    };

    if (typeof wx.nextTick === "function") {
      wx.nextTick(start);
    } else {
      setTimeout(start, 0);
    }
  });
}

module.exports = {
  playPageEntrance
};
