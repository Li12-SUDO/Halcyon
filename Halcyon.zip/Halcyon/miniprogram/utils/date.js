const WEEKDAY_NAMES = ["日", "一", "二", "三", "四", "五", "六"];

function pad(value) {
  return String(value).padStart(2, "0");
}

function toDateString(date) {
  const value = date || new Date();
  return `${value.getFullYear()}-${pad(value.getMonth() + 1)}-${pad(value.getDate())}`;
}

function toTimeString(date) {
  const value = date || new Date();
  return `${pad(value.getHours())}:${pad(value.getMinutes())}`;
}

function monthRange(year, month) {
  const lastDay = new Date(year, month, 0).getDate();
  return {
    startDate: `${year}-${pad(month)}-01`,
    endDate: `${year}-${pad(month)}-${pad(lastDay)}`
  };
}

function dateLabel(dateString) {
  const parts = String(dateString || "").split("-").map(Number);
  if (parts.length !== 3 || parts.some((value) => !value)) return dateString || "";
  const date = new Date(parts[0], parts[1] - 1, parts[2]);
  return `${parts[1]}月${parts[2]}日 · 周${WEEKDAY_NAMES[date.getDay()]}`;
}

function daysSince(dateString, today) {
  const start = new Date(`${dateString}T00:00:00`);
  const end = new Date(`${today || toDateString()}T00:00:00`);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) return 0;
  return Math.max(1, Math.floor((end.getTime() - start.getTime()) / 86400000) + 1);
}

function money(value) {
  return (Number(value) || 0).toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

module.exports = {
  WEEKDAY_NAMES,
  toDateString,
  toTimeString,
  monthRange,
  dateLabel,
  daysSince,
  money
};
