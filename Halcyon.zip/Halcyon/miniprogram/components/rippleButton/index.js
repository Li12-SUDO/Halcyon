Component({
  options: {
    addGlobalClass: true,
    virtualHost: true
  },

  externalClasses: ["custom-class"],

  properties: {
    label: {
      type: String,
      value: ""
    },
    variant: {
      type: String,
      value: "primary"
    },
    compact: {
      type: Boolean,
      value: false
    },
    disabled: {
      type: Boolean,
      value: false
    }
  },

  data: {
    rippleStyle: "",
    rippleAnimation: "a",
    rippleSequence: 0
  },

  lifetimes: {
    attached() {
      this.rippleSequence = 0;
    }
  },

  methods: {
    onTouchStart(e) {
      if (this.properties.disabled || !e.touches.length) return;

      const touch = e.touches[0];
      const sequence = ++this.rippleSequence;
      this.createSelectorQuery()
        .select(".ripple-button")
        .boundingClientRect((rect) => {
          if (!rect || sequence !== this.rippleSequence) return;

          const x = touch.clientX - rect.left;
          const y = touch.clientY - rect.top;
          const radius = Math.hypot(
            Math.max(x, rect.width - x),
            Math.max(y, rect.height - y)
          );
          const diameter = Math.ceil(radius * 2);

          this.setData({
            rippleStyle: `left:${x}px;top:${y}px;width:${diameter}px;height:${diameter}px;`,
            rippleAnimation: sequence % 2 ? "a" : "b",
            rippleSequence: sequence
          });
        })
        .exec();
    },

    onRippleEnd(e) {
      if (Number(e.currentTarget.dataset.sequence) === this.rippleSequence) {
        this.setData({ rippleStyle: "" });
      }
    },

    onTap() {
      if (!this.properties.disabled) this.triggerEvent("action");
    }
  }
});
