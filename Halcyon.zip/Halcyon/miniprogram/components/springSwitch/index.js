Component({
  options: {
    addGlobalClass: true,
    virtualHost: true
  },

  externalClasses: ["custom-class"],

  properties: {
    checked: {
      type: Boolean,
      value: false,
      observer(value) {
        if (value !== this.data.visualChecked) {
          this.setData({ visualChecked: value });
        }
      }
    },
    disabled: {
      type: Boolean,
      value: false
    }
  },

  data: {
    visualChecked: false,
    motionClass: ""
  },

  lifetimes: {
    attached() {
      if (this.properties.checked !== this.data.visualChecked) {
        this.setData({ visualChecked: this.properties.checked });
      }
    }
  },

  methods: {
    onToggle() {
      if (this.properties.disabled) return;

      const value = !this.data.visualChecked;
      this.setData({
        visualChecked: value,
        motionClass: value ? "to-on" : "to-off"
      });
      this.triggerEvent("change", { value });
    },

    onMotionEnd() {
      if (this.data.motionClass) this.setData({ motionClass: "" });
    }
  }
});
