const FUNCTION_NAME = "halcyonData";
const READY_STORAGE_KEY = "halcyon_backend_ready_v1";

let readyPromise = null;

function invoke(action, payload) {
  return new Promise((resolve, reject) => {
    const app = getApp();
    if (!app || !app.initCloud()) {
      reject(new Error("当前基础库不支持云开发"));
      return;
    }

    wx.cloud.callFunction({
      name: FUNCTION_NAME,
      data: Object.assign({ action }, payload || {}),
      success: (response) => {
        const result = response && response.result;
        if (!result || result.success !== true) {
          reject(new Error(result && result.message || "云端数据请求失败"));
          return;
        }
        resolve(result.data);
      },
      fail: (error) => {
        const detail = error && error.errMsg || "";
        if (/FUNCTION_NOT_FOUND|not found|找不到/i.test(detail)) {
          reject(new Error("云函数尚未部署，请先上传并部署 halcyonData"));
          return;
        }
        reject(new Error(detail || "网络连接失败，请稍后重试"));
      }
    });
  });
}

function ensureReady() {
  if (readyPromise) return readyPromise;
  if (wx.getStorageSync(READY_STORAGE_KEY)) {
    readyPromise = Promise.resolve(true);
    return readyPromise;
  }

  readyPromise = invoke("bootstrap")
    .then(() => {
      wx.setStorageSync(READY_STORAGE_KEY, true);
      return true;
    })
    .catch((error) => {
      readyPromise = null;
      throw error;
    });
  return readyPromise;
}

function call(action, payload) {
  return ensureReady().then(() => invoke(action, payload));
}

function list(entity, filters, page, pageSize) {
  return call("list", {
    entity,
    filters: filters || {},
    page: page || 0,
    pageSize: pageSize || 100
  });
}

function get(entity, id) {
  return call("get", { entity, id });
}

function save(entity, data, id) {
  return call("save", { entity, data, id: id || "" });
}

function remove(entity, id) {
  return call("remove", { entity, id });
}

function dashboard(today) {
  return call("dashboard", { today });
}

function toggleFavorite(data) {
  return call("toggleFavorite", { data });
}

function favoriteStatus(content) {
  return call("favoriteStatus", { content });
}

function clearAll() {
  return call("clearAll");
}

function resetBackendState() {
  readyPromise = null;
  wx.removeStorageSync(READY_STORAGE_KEY);
}

function showError(error) {
  const message = error && error.message || "数据加载失败";
  wx.showToast({ title: message.slice(0, 20), icon: "none", duration: 2600 });
}

module.exports = {
  list,
  get,
  save,
  remove,
  dashboard,
  toggleFavorite,
  favoriteStatus,
  clearAll,
  resetBackendState,
  showError
};
