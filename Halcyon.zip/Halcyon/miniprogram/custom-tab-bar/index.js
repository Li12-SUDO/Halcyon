Component({
  data: {
    selected: 0,
    list: [
      { path: "/pages/home/index", text: "首页" },
      { path: "/pages/ledger/index", text: "记账" },
      { path: "/pages/calendar/index", text: "日历" },
      { path: "/pages/health/index", text: "健康" },
      { path: "/pages/profile/index", text: "我的" }
    ]
  },
  methods: {
    onTap(e) {
      const index = Number(e.currentTarget.dataset.index);
      const path = e.currentTarget.dataset.path || (this.data.list[index] && this.data.list[index].path);
      if (!path || Number.isNaN(index)) return;
      if (index === this.data.selected) return;

      this.setData({ selected: index });
      wx.switchTab({ url: path });
    }
  }
});
