App({
  globalData: {
    env: "cloudbase-d6ge5nbgu9081b7cf"
  },

  onLaunch() {
    this.initCloud();
  },

  initCloud() {
    if (this.cloudReady) return true;
    if (!wx.cloud) return false;

    wx.cloud.init({
      env: this.globalData.env,
      traceUser: true
    });
    this.cloudReady = true;
    return true;
  }
});
