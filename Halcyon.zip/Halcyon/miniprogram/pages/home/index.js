const { playPageEntrance } = require("../../utils/pageEntrance");
const dataService = require("../../services/dataService");
const { WEEKDAY_NAMES, toDateString, daysSince, money } = require("../../utils/date");

const QUOTES = [
  { content: "把时间花在值得的事情上，平凡的日子也会发光。", author: "Halcyon 日常", category: "自省", tone: "yellow" },
  { content: "慢一点没有关系，持续向前就好。", author: "", category: "成长", tone: "green" },
  { content: "先照顾好今天的自己，再谈明天。", author: "佚名", category: "生活", tone: "blue" },
  { content: "记录不是束缚，是给未来的自己留一盏灯。", author: "", category: "记录", tone: "red" }
];

const ACTION_ROUTES = {
  ledger: "/pages/ledger/edit",
  todo: "/pages/todo/edit",
  health: "/pages/health/edit",
  anniversary: "/pages/anniversary/edit"
};

Page({
  data: {
    greeting: "你好",
    dateMeta: "",
    quote: QUOTES[0],
    summary: [
      { label: "今日支出", value: "¥0.00", tone: "c-red" },
      { label: "今日收入", value: "¥0.00", tone: "c-green" },
      { label: "待办完成", value: "0 / 0", tone: "c-blue" },
      { label: "健康记录", value: "未记录", tone: "c-yellow" }
    ],
    actions: [
      { key: "ledger", glyph: "＋", label: "记一笔" },
      { key: "todo", glyph: "✓", label: "添加待办" },
      { key: "health", glyph: "▤", label: "记录健康" },
      { key: "anniversary", glyph: "◆", label: "纪念日" }
    ],
    anniversary: { name: "还没有纪念日", start: "添加一个值得记住的日子", days: "—" },
    loading: true
  },

  onLoad() {
    const now = new Date();
    const quote = this.getQuote(now);
    this.setData(Object.assign({}, this.getDateData(now), { quote }));
  },

  onShow() {
    playPageEntrance(this);
    this.syncTabBar();
    this.loadDashboard();
    this.loadFavoriteStatus();
  },

  syncTabBar() {
    if (typeof this.getTabBar !== "function") return;
    const tabBar = this.getTabBar();
    if (tabBar && tabBar.data.selected !== 0) tabBar.setData({ selected: 0 });
  },

  getDateData(date) {
    const hour = date.getHours();
    let greeting = "晚上好";
    if (hour < 6) greeting = "夜深了";
    else if (hour < 11) greeting = "早上好";
    else if (hour < 14) greeting = "中午好";
    else if (hour < 18) greeting = "下午好";
    return { greeting, dateMeta: `${date.getMonth() + 1}月${date.getDate()}日 · 周${WEEKDAY_NAMES[date.getDay()]}` };
  },

  getQuote(date) {
    const key = `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
    let hash = 0;
    for (let index = 0; index < key.length; index += 1) hash = (hash * 31 + key.charCodeAt(index)) >>> 0;
    return Object.assign({ favorited: false }, QUOTES[hash % QUOTES.length]);
  },

  loadDashboard() {
    this.setData({ loading: true });
    dataService.dashboard(toDateString()).then((result) => {
      const anniversary = result.latestAnniversary;
      this.setData({
        loading: false,
        summary: [
          { label: "今日支出", value: `¥${money(result.todayExpense)}`, tone: "c-red" },
          { label: "今日收入", value: `¥${money(result.todayIncome)}`, tone: "c-green" },
          { label: "待办完成", value: `${result.todoTodayDone} / ${result.todoTodayTotal}`, tone: "c-blue" },
          { label: "健康记录", value: result.healthRecordedToday ? "已记录" : "未记录", tone: "c-yellow" }
        ],
        anniversary: anniversary ? {
          name: anniversary.name,
          start: `${anniversary.date} 起`,
          days: daysSince(anniversary.date)
        } : { name: "还没有纪念日", start: "添加一个值得记住的日子", days: "—" }
      });
    }).catch((error) => {
      this.setData({ loading: false });
      dataService.showError(error);
    });
  },

  loadFavoriteStatus() {
    dataService.favoriteStatus(this.data.quote.content).then((status) => {
      this.setData({ "quote.favorited": status.favorited });
    }).catch(() => {});
  },

  onToggleFav() {
    if (this.favoritePending) return;
    this.favoritePending = true;
    dataService.toggleFavorite(this.data.quote).then((result) => {
      this.setData({ "quote.favorited": result.favorited });
      wx.showToast({ title: result.favorited ? "已收藏" : "已取消收藏", icon: "none" });
    }).catch(dataService.showError).then(() => { this.favoritePending = false; });
  },

  onShare() { wx.setClipboardData({ data: this.data.quote.content }); },

  onAction(e) {
    const url = ACTION_ROUTES[e.currentTarget.dataset.key];
    if (url) wx.navigateTo({ url });
  },

  goAnniversary() { wx.navigateTo({ url: "/pages/anniversary/index" }); }
});
