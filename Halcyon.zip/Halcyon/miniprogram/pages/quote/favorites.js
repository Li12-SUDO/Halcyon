const { playPageEntrance } = require("../../utils/pageEntrance");
const dataService = require("../../services/dataService");

Page({
  data: { list: [], loading: true },

  onShow() {
    playPageEntrance(this);
    this.loadFavorites();
  },

  loadFavorites() {
    this.setData({ loading: true });
    dataService.list("quoteFavorites").then((result) => {
      this.setData({
        loading: false,
        list: (result.items || []).map((record) => ({
          id: record._id,
          content: record.content,
          author: record.author,
          category: record.category,
          tone: `tag-${record.tone || "yellow"}`
        }))
      });
    }).catch((error) => {
      this.setData({ loading: false });
      dataService.showError(error);
    });
  },

  onUnfav(e) {
    const id = e.currentTarget.dataset.id;
    dataService.remove("quoteFavorites", id).then(() => {
      this.setData({ list: this.data.list.filter((quote) => quote.id !== id) });
      wx.showToast({ title: "已取消收藏", icon: "none" });
    }).catch(dataService.showError);
  }
});
