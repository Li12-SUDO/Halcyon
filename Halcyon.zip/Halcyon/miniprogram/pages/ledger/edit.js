const { playPageEntrance } = require("../../utils/pageEntrance");
const dataService = require("../../services/dataService");
const { toDateString, toTimeString } = require("../../utils/date");

const EXPENSE_CATEGORIES = ["餐饮", "交通", "购物", "居住", "娱乐", "医疗", "其他"];
const INCOME_CATEGORIES = ["工资", "奖金", "理财", "报销", "其他"];

Page({
  data: {
    id: "",
    typeOptions: [{ key: "expense", label: "支出" }, { key: "income", label: "收入" }],
    type: "expense",
    amount: "",
    categories: EXPENSE_CATEGORIES,
    selectedCategory: "餐饮",
    note: "",
    date: "",
    time: "",
    saving: false
  },

  onLoad(options) {
    const now = new Date();
    this.formData = { amount: "", note: "" };
    this.setData({ date: toDateString(now), time: toTimeString(now) });
    if (options && options.id) this.loadRecord(options.id);
  },

  onShow() { playPageEntrance(this); },

  loadRecord(id) {
    dataService.get("ledger", id).then((record) => {
      if (!record) throw new Error("这笔记录不存在");
      const categories = record.type === "income" ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;
      this.formData = { amount: String(record.amount), note: record.note || "" };
      this.setData({
        id: record._id,
        type: record.type,
        amount: String(record.amount),
        categories,
        selectedCategory: record.category,
        note: record.note || "",
        date: record.date,
        time: record.time
      });
      wx.setNavigationBarTitle({ title: "编辑账目" });
    }).catch(dataService.showError);
  },

  onType(e) {
    const type = e.currentTarget.dataset.key;
    if (type === this.data.type) return;
    const categories = type === "expense" ? EXPENSE_CATEGORIES : INCOME_CATEGORIES;
    this.setData({ type, categories, selectedCategory: categories[0] });
  },

  onAmountInput(e) { this.formData.amount = e.detail.value; },
  onNoteInput(e) { this.formData.note = e.detail.value; },
  onDateChange(e) { this.setData({ date: e.detail.value }); },
  onTimeChange(e) { this.setData({ time: e.detail.value }); },

  onPickCategory(e) {
    const selectedCategory = e.currentTarget.dataset.name;
    if (selectedCategory !== this.data.selectedCategory) this.setData({ selectedCategory });
  },

  onSave() {
    if (this.data.saving) return;
    const amount = Number(this.formData.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      wx.showToast({ title: "请输入有效金额", icon: "none" });
      return;
    }
    this.setData({ saving: true });
    dataService.save("ledger", {
      type: this.data.type,
      amount,
      category: this.data.selectedCategory,
      note: this.formData.note,
      date: this.data.date,
      time: this.data.time
    }, this.data.id).then(() => {
      wx.showToast({ title: "已保存", icon: "success" });
      setTimeout(() => wx.navigateBack(), 300);
    }).catch((error) => {
      this.setData({ saving: false });
      dataService.showError(error);
    });
  }
});
