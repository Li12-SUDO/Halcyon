const { playPageEntrance } = require("../../utils/pageEntrance");
const dataService = require("../../services/dataService");
const { money } = require("../../utils/date");

const CATEGORY_TONES = {
  "餐饮": "tag-yellow", "交通": "tag-blue", "购物": "tag-red",
  "居住": "tag-green", "娱乐": "tag-yellow", "医疗": "tag-red",
  "工资": "tag-green", "奖金": "tag-green", "理财": "tag-blue", "报销": "tag-blue"
};

Page({
  data: { id: "", record: null, loading: true },

  onLoad(options) { this.setData({ id: options && options.id || "" }); },

  onShow() {
    playPageEntrance(this);
    if (this.data.id) this.loadRecord();
  },

  loadRecord() {
    this.setData({ loading: true });
    dataService.get("ledger", this.data.id).then((record) => {
      if (!record) throw new Error("这笔记录不存在");
      this.setData({
        loading: false,
        record: {
          category: record.category,
          amount: money(record.amount),
          amountTone: record.type === "income" ? "c-green" : "c-red",
          type: record.type === "income" ? "收入" : "支出",
          tone: CATEGORY_TONES[record.category] || "tag-yellow",
          note: record.note || "无备注",
          date: record.date,
          time: record.time
        }
      });
    }).catch((error) => {
      this.setData({ loading: false });
      dataService.showError(error);
    });
  },

  onEdit() { wx.navigateTo({ url: "/pages/ledger/edit?id=" + this.data.id }); },

  onDelete() {
    wx.showModal({
      title: "删除这笔记录",
      content: "删除后无法恢复，确定继续吗？",
      confirmColor: "#9F2F2D",
      success: (res) => {
        if (!res.confirm) return;
        dataService.remove("ledger", this.data.id).then(() => {
          wx.showToast({ title: "已删除", icon: "success" });
          setTimeout(() => wx.navigateBack(), 300);
        }).catch(dataService.showError);
      }
    });
  }
});
