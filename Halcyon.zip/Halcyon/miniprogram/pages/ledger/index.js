const { playPageEntrance } = require("../../utils/pageEntrance");
const dataService = require("../../services/dataService");
const { monthRange, dateLabel, money } = require("../../utils/date");

const CATEGORY_TONES = {
  "餐饮": "tag-yellow", "交通": "tag-blue", "购物": "tag-red",
  "居住": "tag-green", "娱乐": "tag-yellow", "医疗": "tag-red",
  "工资": "tag-green", "奖金": "tag-green", "理财": "tag-blue", "报销": "tag-blue"
};

function buildMonths() {
  const now = new Date();
  const months = [];
  for (let offset = 12; offset >= 0; offset -= 1) {
    const date = new Date(now.getFullYear(), now.getMonth() - offset, 1);
    months.push({
      year: date.getFullYear(),
      month: date.getMonth() + 1,
      label: `${date.getFullYear()}年${date.getMonth() + 1}月`
    });
  }
  return months;
}

Page({
  data: {
    monthIndex: 12,
    months: [],
    monthExpense: "0.00",
    monthIncome: "0.00",
    monthBalance: "0.00",
    groups: [],
    loading: true
  },

  onLoad() {
    this.monthOptions = buildMonths();
    this.setData({ months: this.monthOptions.map((item) => item.label) });
  },

  onShow() {
    playPageEntrance(this);
    this.syncTabBar();
    this.loadRecords();
  },

  syncTabBar() {
    if (typeof this.getTabBar !== "function") return;
    const tabBar = this.getTabBar();
    if (tabBar && tabBar.data.selected !== 1) tabBar.setData({ selected: 1 });
  },

  loadRecords() {
    const selected = this.monthOptions && this.monthOptions[this.data.monthIndex];
    if (!selected) return;
    const requestId = (this.recordsRequestId || 0) + 1;
    this.recordsRequestId = requestId;
    this.setData({ loading: true });

    dataService.list("ledger", monthRange(selected.year, selected.month))
      .then((result) => {
        if (this.recordsRequestId !== requestId) return;
        this.applyRecords(result.items || []);
      })
      .catch((error) => {
        if (this.recordsRequestId !== requestId) return;
        this.setData({ loading: false });
        dataService.showError(error);
      });
  },

  applyRecords(records) {
    let expense = 0;
    let income = 0;
    const grouped = {};

    records.forEach((record) => {
      const amount = Number(record.amount) || 0;
      if (record.type === "income") income += amount;
      else expense += amount;
      if (!grouped[record.date]) grouped[record.date] = [];
      grouped[record.date].push(record);
    });

    const groups = Object.keys(grouped).sort().reverse().map((date) => {
      let dayExpense = 0;
      let dayIncome = 0;
      const items = grouped[date].map((record) => {
        const amount = Number(record.amount) || 0;
        if (record.type === "income") dayIncome += amount;
        else dayExpense += amount;
        return {
          id: record._id,
          glyph: record.category.slice(0, 1),
          tone: CATEGORY_TONES[record.category] || "tag-yellow",
          name: record.category,
          note: record.note || "无备注",
          time: record.time,
          amount: `${record.type === "income" ? "+" : "-"}${money(amount)}`,
          amountTone: record.type === "income" ? "c-green" : "c-red"
        };
      });
      let total = `支出 ¥${money(dayExpense)}`;
      if (!dayExpense) total = `收入 ¥${money(dayIncome)}`;
      else if (dayIncome) total = `收 ¥${money(dayIncome)} · 支 ¥${money(dayExpense)}`;
      return { date: dateLabel(date), total, items };
    });

    this.setData({
      monthExpense: money(expense),
      monthIncome: money(income),
      monthBalance: money(income - expense),
      groups,
      loading: false
    });
  },

  prevMonth() {
    if (this.data.monthIndex <= 0) return;
    this.setData({ monthIndex: this.data.monthIndex - 1 }, () => this.loadRecords());
  },

  nextMonth() {
    if (this.data.monthIndex >= this.data.months.length - 1) return;
    this.setData({ monthIndex: this.data.monthIndex + 1 }, () => this.loadRecords());
  },

  goAdd() { wx.navigateTo({ url: "/pages/ledger/edit" }); },
  goAnalysis() { wx.navigateTo({ url: "/pages/analysis/index?type=ledger" }); },
  goDetail(e) { wx.navigateTo({ url: "/pages/ledger/detail?id=" + e.currentTarget.dataset.id }); }
});
