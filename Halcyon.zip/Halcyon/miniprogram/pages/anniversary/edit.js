const { playPageEntrance } = require("../../utils/pageEntrance");
const dataService = require("../../services/dataService");
const { toDateString } = require("../../utils/date");

Page({
  data: { id: "", name: "", date: "", memo: "", saving: false },

  onLoad(options) {
    this.formData = { name: "", memo: "" };
    this.setData({ date: toDateString() });
    if (options && options.id) this.loadAnniversary(options.id);
  },

  onShow() { playPageEntrance(this); },

  loadAnniversary(id) {
    dataService.get("anniversaries", id).then((record) => {
      if (!record) throw new Error("这个纪念日不存在");
      this.formData = { name: record.name, memo: record.memo || "" };
      this.setData({ id: record._id, name: record.name, date: record.date, memo: record.memo || "" });
      wx.setNavigationBarTitle({ title: "编辑纪念日" });
    }).catch(dataService.showError);
  },

  onNameInput(e) { this.formData.name = e.detail.value; },
  onMemoInput(e) { this.formData.memo = e.detail.value; },
  onDateChange(e) { this.setData({ date: e.detail.value }); },

  onSave() {
    if (this.data.saving) return;
    const name = this.formData.name.trim();
    if (!name) {
      wx.showToast({ title: "请输入名称", icon: "none" });
      return;
    }
    this.setData({ saving: true });
    dataService.save("anniversaries", {
      name,
      date: this.data.date,
      memo: this.formData.memo
    }, this.data.id).then(() => {
      wx.showToast({ title: "已保存", icon: "success" });
      setTimeout(() => wx.navigateBack(), 300);
    }).catch((error) => {
      this.setData({ saving: false });
      dataService.showError(error);
    });
  },

  onDelete() {
    if (!this.data.id) return;
    wx.showModal({
      title: "删除纪念日",
      content: "删除后无法恢复，确定继续吗？",
      confirmColor: "#9F2F2D",
      success: (res) => {
        if (!res.confirm) return;
        dataService.remove("anniversaries", this.data.id).then(() => {
          wx.showToast({ title: "已删除", icon: "success" });
          setTimeout(() => wx.navigateBack(), 300);
        }).catch(dataService.showError);
      }
    });
  }
});
