const { playPageEntrance } = require("../../utils/pageEntrance");
const dataService = require("../../services/dataService");
const { daysSince } = require("../../utils/date");

Page({
  data: { list: [], loading: true },

  onShow() {
    playPageEntrance(this);
    this.loadAnniversaries();
  },

  loadAnniversaries() {
    this.setData({ loading: true });
    dataService.list("anniversaries").then((result) => {
      this.setData({
        loading: false,
        list: (result.items || []).map((record) => ({
          id: record._id,
          name: record.name,
          date: record.date,
          days: daysSince(record.date),
          tag: "纪念",
          tone: "tag-green"
        }))
      });
    }).catch((error) => {
      this.setData({ loading: false });
      dataService.showError(error);
    });
  },

  goAdd() { wx.navigateTo({ url: "/pages/anniversary/edit" }); },
  goEdit(e) { wx.navigateTo({ url: "/pages/anniversary/edit?id=" + e.currentTarget.dataset.id }); }
});
