const { playPageEntrance } = require("../../utils/pageEntrance");
const dataService = require("../../services/dataService");
const { toDateString } = require("../../utils/date");

const MENU_ROUTES = {
  quote: "/pages/quote/favorites",
  anniversary: "/pages/anniversary/index",
  analysis: "/pages/analysis/index",
  settings: "/pages/settings/index"
};

Page({
  data: {
    name: "微信用户",
    stats: [
      { value: "0", label: "账目记录" },
      { value: "0", label: "待办完成" },
      { value: "0", label: "纪念日" }
    ],
    menus: [
      { key: "quote", label: "一言收藏" },
      { key: "anniversary", label: "纪念日管理" },
      { key: "analysis", label: "数据分析" },
      { key: "settings", label: "设置" }
    ]
  },

  onShow() {
    playPageEntrance(this);
    this.syncTabBar();
    this.loadStats();
  },

  syncTabBar() {
    if (typeof this.getTabBar !== "function") return;
    const tabBar = this.getTabBar();
    if (tabBar && tabBar.data.selected !== 4) tabBar.setData({ selected: 4 });
  },

  loadStats() {
    dataService.dashboard(toDateString()).then((result) => {
      this.setData({ stats: [
        { value: String(result.stats.ledgerRecords), label: "账目记录" },
        { value: String(result.stats.todoDone), label: "待办完成" },
        { value: String(result.stats.anniversaries), label: "纪念日" }
      ] });
    }).catch(dataService.showError);
  },

  go(e) {
    const url = MENU_ROUTES[e.currentTarget.dataset.key];
    if (url) wx.navigateTo({ url });
  }
});
