const { playPageEntrance } = require("../../utils/pageEntrance");
const dataService = require("../../services/dataService");
const { toDateString } = require("../../utils/date");

Page({
  data: { weight: "", bodyFat: "", date: "", saving: false },

  onLoad() {
    this.formData = { weight: "", bodyFat: "" };
    this.setData({ date: toDateString() });
  },

  onShow() { playPageEntrance(this); },
  onWeightInput(e) { this.formData.weight = e.detail.value; },
  onBodyFatInput(e) { this.formData.bodyFat = e.detail.value; },
  onDateChange(e) { this.setData({ date: e.detail.value }); },

  onSave() {
    if (this.data.saving) return;
    const weight = Number(this.formData.weight);
    const bodyFat = this.formData.bodyFat === "" ? "" : Number(this.formData.bodyFat);
    if (!Number.isFinite(weight) || weight < 20 || weight > 500) {
      wx.showToast({ title: "请输入有效体重", icon: "none" });
      return;
    }
    if (bodyFat !== "" && (!Number.isFinite(bodyFat) || bodyFat < 1 || bodyFat > 80)) {
      wx.showToast({ title: "请输入有效体脂", icon: "none" });
      return;
    }
    this.setData({ saving: true });
    dataService.save("health", { weight, bodyFat, date: this.data.date }).then((result) => {
      wx.showToast({ title: result.updated ? "已更新" : "已保存", icon: "success" });
      setTimeout(() => wx.navigateBack(), 300);
    }).catch((error) => {
      this.setData({ saving: false });
      dataService.showError(error);
    });
  }
});
