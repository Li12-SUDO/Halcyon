const { playPageEntrance } = require("../../utils/pageEntrance");
const dataService = require("../../services/dataService");
const { toDateString } = require("../../utils/date");

function offsetDate(days) {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return toDateString(date);
}

function shortDate(date) {
  const parts = date.split("-");
  return `${Number(parts[1])}/${Number(parts[2])}`;
}

Page({
  data: {
    weight: "--",
    bodyFat: "--",
    updatedAt: "还没有健康记录",
    periods: [{ key: 7, label: "7天" }, { key: 30, label: "30天" }, { key: 90, label: "90天" }],
    period: 7,
    bars: [],
    records: [],
    loading: true
  },

  onLoad() { this.healthRecords = []; },

  onShow() {
    playPageEntrance(this);
    this.syncTabBar();
    this.loadHealth();
  },

  syncTabBar() {
    if (typeof this.getTabBar !== "function") return;
    const tabBar = this.getTabBar();
    if (tabBar && tabBar.data.selected !== 3) tabBar.setData({ selected: 3 });
  },

  loadHealth() {
    this.setData({ loading: true });
    dataService.list("health", { startDate: offsetDate(89), endDate: toDateString() }).then((result) => {
      this.healthRecords = result.items || [];
      const latest = this.healthRecords[0];
      this.setData({
        weight: latest ? Number(latest.weight).toFixed(1) : "--",
        bodyFat: latest && latest.bodyFat != null ? Number(latest.bodyFat).toFixed(1) : "--",
        updatedAt: latest ? `${shortDate(latest.date)} 更新` : "还没有健康记录",
        records: this.healthRecords.slice(0, 10).map((record) => ({
          id: record._id,
          date: `${Number(record.date.slice(5, 7))}月${Number(record.date.slice(8, 10))}日`,
          weight: Number(record.weight).toFixed(1),
          bodyFat: record.bodyFat == null ? "--" : `${Number(record.bodyFat).toFixed(1)}%`
        })),
        loading: false
      }, () => this.renderTrend(this.data.period));
    }).catch((error) => {
      this.setData({ loading: false });
      dataService.showError(error);
    });
  },

  renderTrend(period) {
    const cutoff = offsetDate(period - 1);
    const selected = this.healthRecords.filter((record) => record.date >= cutoff).slice().reverse();
    const points = selected.length > 7
      ? selected.filter((item, index) => index % Math.ceil(selected.length / 7) === 0).slice(-7)
      : selected;
    if (!points.length) {
      this.setData({ period, bars: [] });
      return;
    }
    const values = points.map((record) => Number(record.weight));
    const min = Math.min.apply(null, values);
    const max = Math.max.apply(null, values);
    const range = max - min || 1;
    const bars = points.map((record, index) => ({
      label: shortDate(record.date),
      value: Number(record.weight).toFixed(1),
      height: Math.round(28 + ((Number(record.weight) - min) / range) * 64),
      accent: index === points.length - 1
    }));
    this.setData({ period, bars });
  },

  onPeriod(e) {
    const period = Number(e.currentTarget.dataset.key);
    if (period !== this.data.period) this.renderTrend(period);
  },

  goEdit() { wx.navigateTo({ url: "/pages/health/edit" }); },
  goAnalysis() { wx.navigateTo({ url: "/pages/analysis/index?type=health" }); }
});
