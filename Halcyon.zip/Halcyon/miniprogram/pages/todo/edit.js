const { playPageEntrance } = require("../../utils/pageEntrance");
const dataService = require("../../services/dataService");
const { toDateString } = require("../../utils/date");

Page({
  data: {
    id: "",
    title: "",
    priorities: ["低", "中", "高"],
    priority: "中",
    done: false,
    date: "",
    saving: false
  },

  onLoad(options) {
    this.formData = { title: "" };
    this.setData({ date: options && options.date || toDateString() });
    if (options && options.id) this.loadTodo(options.id);
  },

  onShow() { playPageEntrance(this); },

  loadTodo(id) {
    dataService.get("todos", id).then((todo) => {
      if (!todo) throw new Error("这条待办不存在");
      this.formData.title = todo.title;
      this.setData({
        id: todo._id,
        title: todo.title,
        priority: todo.priority,
        done: todo.done,
        date: todo.date
      });
      wx.setNavigationBarTitle({ title: "编辑待办" });
    }).catch(dataService.showError);
  },

  onTitleInput(e) { this.formData.title = e.detail.value; },
  onDoneChange(e) { this.setData({ done: e.detail.value }); },
  onDateChange(e) { this.setData({ date: e.detail.value }); },

  onPriority(e) {
    const priority = e.currentTarget.dataset.value;
    if (priority !== this.data.priority) this.setData({ priority });
  },

  onSave() {
    if (this.data.saving) return;
    const title = this.formData.title.trim();
    if (!title) {
      wx.showToast({ title: "请输入事项", icon: "none" });
      return;
    }
    this.setData({ saving: true });
    dataService.save("todos", {
      title,
      priority: this.data.priority,
      done: this.data.done,
      date: this.data.date
    }, this.data.id).then(() => {
      wx.showToast({ title: "已保存", icon: "success" });
      setTimeout(() => wx.navigateBack(), 300);
    }).catch((error) => {
      this.setData({ saving: false });
      dataService.showError(error);
    });
  },

  onDelete() {
    if (!this.data.id) {
      wx.navigateBack();
      return;
    }
    wx.showModal({
      title: "删除事项",
      content: "删除后无法恢复，确定继续吗？",
      confirmColor: "#9F2F2D",
      success: (res) => {
        if (!res.confirm) return;
        dataService.remove("todos", this.data.id).then(() => {
          wx.showToast({ title: "已删除", icon: "success" });
          setTimeout(() => wx.navigateBack(), 300);
        }).catch(dataService.showError);
      }
    });
  }
});
