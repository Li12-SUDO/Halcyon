const { playPageEntrance } = require("../../utils/pageEntrance");
const dataService = require("../../services/dataService");

Page({
  data: { cloudStatus: "已连接", sync: true, version: "1.0.0" },

  onShow() {
    playPageEntrance(this);
    this.loadSettings();
  },

  loadSettings() {
    dataService.list("settings").then((result) => {
      const settings = result.items && result.items[0];
      if (settings) this.setData({ sync: settings.sync !== false });
    }).catch((error) => {
      this.setData({ cloudStatus: "连接失败" });
      dataService.showError(error);
    });
  },

  onSyncChange(e) {
    const sync = e.detail.value;
    this.setData({ sync });
    dataService.save("settings", { sync }).catch((error) => {
      this.setData({ sync: !sync });
      dataService.showError(error);
    });
  },

  onClearData() {
    wx.showModal({
      title: "删除全部云端数据",
      content: "账目、待办、健康、纪念日和收藏将永久删除，无法恢复。",
      confirmText: "全部删除",
      confirmColor: "#9F2F2D",
      success: (res) => {
        if (!res.confirm) return;
        wx.showLoading({ title: "正在删除" });
        dataService.clearAll().then(() => {
          dataService.resetBackendState();
          wx.hideLoading();
          this.setData({ sync: true });
          wx.showToast({ title: "数据已删除", icon: "success" });
        }).catch((error) => {
          wx.hideLoading();
          dataService.showError(error);
        });
      }
    });
  },

  onPrivacy() {
    wx.showModal({
      title: "隐私保护指引",
      content: "我们仅保存你主动录入的账目、待办、体重体脂、纪念日和收藏数据。数据按微信用户隔离，你可在本页随时删除全部云端数据。",
      showCancel: false,
      confirmColor: "#171716"
    });
  },

  onAgreement() {
    wx.showModal({
      title: "用户协议",
      content: "使用本服务即表示你同意妥善管理个人数据，并遵守相关法律法规。",
      showCancel: false,
      confirmColor: "#171716"
    });
  }
});
