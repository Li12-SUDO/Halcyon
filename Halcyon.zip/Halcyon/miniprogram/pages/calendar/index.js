const { playPageEntrance } = require("../../utils/pageEntrance");
const dataService = require("../../services/dataService");
const { WEEKDAY_NAMES, monthRange, toDateString } = require("../../utils/date");

Page({
  data: {
    year: 0,
    month: 0,
    monthLabel: "",
    weekdays: ["一", "二", "三", "四", "五", "六", "日"],
    days: [],
    selectedDay: 0,
    selectedLabel: "",
    monthTodoCount: 0,
    monthDoneCount: 0,
    todos: [],
    loading: true
  },

  onLoad() {
    const now = new Date();
    this.monthTodos = [];
    this.setData({
      year: now.getFullYear(),
      month: now.getMonth() + 1,
      selectedDay: now.getDate()
    });
    this.renderCalendar();
  },

  onShow() {
    playPageEntrance(this);
    this.syncTabBar();
    this.loadMonthTodos();
  },

  syncTabBar() {
    if (typeof this.getTabBar !== "function") return;
    const tabBar = this.getTabBar();
    if (tabBar && tabBar.data.selected !== 2) tabBar.setData({ selected: 2 });
  },

  selectedDate() {
    return `${this.data.year}-${String(this.data.month).padStart(2, "0")}-${String(this.data.selectedDay).padStart(2, "0")}`;
  },

  loadMonthTodos() {
    if (!this.data.year || !this.data.month) return;
    const requestId = (this.todosRequestId || 0) + 1;
    this.todosRequestId = requestId;
    this.setData({ loading: true });
    dataService.list("todos", monthRange(this.data.year, this.data.month)).then((result) => {
      if (this.todosRequestId !== requestId) return;
      this.monthTodos = result.items || [];
      this.renderCalendar();
    }).catch((error) => {
      if (this.todosRequestId !== requestId) return;
      this.setData({ loading: false });
      dataService.showError(error);
    });
  },

  renderCalendar() {
    const { year, month, selectedDay } = this.data;
    if (!year || !month || !selectedDay) return;
    const first = new Date(year, month - 1, 1);
    const daysInMonth = new Date(year, month, 0).getDate();
    const leading = (first.getDay() + 6) % 7;
    const todoDays = new Set(this.monthTodos.map((todo) => Number(todo.date.slice(8, 10))));
    const today = toDateString();
    const days = [];

    for (let index = 0; index < leading; index += 1) days.push({ id: "b" + index, blank: true });
    for (let day = 1; day <= daysInMonth; day += 1) {
      const date = `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
      days.push({
        id: "d" + day,
        day,
        hasTodo: todoDays.has(day),
        isToday: date === today,
        selected: day === selectedDay
      });
    }

    const selectedDate = this.selectedDate();
    const selectedTodos = this.monthTodos.filter((todo) => todo.date === selectedDate).map((todo) => ({
      id: todo._id,
      title: todo.title,
      done: todo.done,
      time: `${todo.priority}优先级`
    }));
    const weekday = new Date(year, month - 1, selectedDay).getDay();
    this.setData({
      days,
      monthLabel: `${year}年${month}月`,
      selectedLabel: `${month}月${selectedDay}日 · 周${WEEKDAY_NAMES[weekday]}`,
      monthTodoCount: this.monthTodos.length,
      monthDoneCount: this.monthTodos.filter((todo) => todo.done).length,
      todos: selectedTodos,
      loading: false
    });
  },

  onSelectDay(e) {
    const selectedDay = Number(e.currentTarget.dataset.day);
    if (selectedDay !== this.data.selectedDay) this.setData({ selectedDay }, () => this.renderCalendar());
  },

  prevMonth() { this.shiftMonth(-1); },
  nextMonth() { this.shiftMonth(1); },

  shiftMonth(delta) {
    const date = new Date(this.data.year, this.data.month - 1 + delta, 1);
    this.monthTodos = [];
    this.setData({
      year: date.getFullYear(),
      month: date.getMonth() + 1,
      selectedDay: 1,
      todos: [],
      loading: true
    }, () => {
      this.renderCalendar();
      this.loadMonthTodos();
    });
  },

  toggleTodo(e) {
    const id = e.currentTarget.dataset.id;
    const source = this.monthTodos.find((todo) => todo._id === id);
    if (!source) return;
    const nextDone = !source.done;
    source.done = nextDone;
    this.renderCalendar();
    dataService.save("todos", {
      title: source.title,
      date: source.date,
      priority: source.priority,
      done: nextDone
    }, id).catch((error) => {
      source.done = !nextDone;
      this.renderCalendar();
      dataService.showError(error);
    });
  },

  goTodoEdit(e) {
    const id = e && e.currentTarget && e.currentTarget.dataset.id;
    const suffix = id ? `?id=${id}` : `?date=${this.selectedDate()}`;
    wx.navigateTo({ url: "/pages/todo/edit" + suffix });
  }
});
