const { playPageEntrance } = require("../../utils/pageEntrance");
const dataService = require("../../services/dataService");
const { monthRange, toDateString, money } = require("../../utils/date");

const CATEGORY_TONES = ["bar-yellow", "bar-green", "bar-red", "bar-blue", "bar-yellow"];

function dateOffset(days) {
  const date = new Date();
  date.setDate(date.getDate() - days);
  return toDateString(date);
}

Page({
  data: {
    tab: "ledger",
    tabs: [{ key: "ledger", label: "账目" }, { key: "health", label: "健康" }],
    totalExpense: "0.00",
    totalIncome: "0.00",
    totalBalance: "0.00",
    categories: [],
    stats: [
      { label: "平均", value: "--", unit: "kg" },
      { label: "最低", value: "--", unit: "kg" },
      { label: "最高", value: "--", unit: "kg" }
    ],
    healthBars: [],
    loading: true
  },

  onLoad(options) {
    if (options && options.type === "health") this.setData({ tab: "health" });
  },

  onShow() {
    playPageEntrance(this);
    this.loadAnalysis();
  },

  loadAnalysis() {
    const now = new Date();
    this.setData({ loading: true });
    Promise.all([
      dataService.list("ledger", monthRange(now.getFullYear(), now.getMonth() + 1)),
      dataService.list("health", { startDate: dateOffset(89), endDate: toDateString() })
    ]).then(([ledgerResult, healthResult]) => {
      this.applyLedger(ledgerResult.items || []);
      this.applyHealth(healthResult.items || []);
      this.setData({ loading: false });
    }).catch((error) => {
      this.setData({ loading: false });
      dataService.showError(error);
    });
  },

  applyLedger(records) {
    let expense = 0;
    let income = 0;
    const categoryTotals = {};
    records.forEach((record) => {
      const amount = Number(record.amount) || 0;
      if (record.type === "income") income += amount;
      else {
        expense += amount;
        categoryTotals[record.category] = (categoryTotals[record.category] || 0) + amount;
      }
    });
    const categories = Object.keys(categoryTotals)
      .map((name) => ({ name, total: categoryTotals[name] }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 5)
      .map((item, index) => ({
        name: item.name,
        amount: `¥${money(item.total)}`,
        pct: expense ? Math.round(item.total / expense * 100) : 0,
        tone: CATEGORY_TONES[index]
      }));
    this.setData({
      totalExpense: money(expense),
      totalIncome: money(income),
      totalBalance: money(income - expense),
      categories
    });
  },

  applyHealth(records) {
    if (!records.length) {
      this.setData({ healthBars: [] });
      return;
    }
    const ordered = records.slice().reverse();
    const sampled = ordered.length > 5
      ? ordered.filter((item, index) => index % Math.ceil(ordered.length / 5) === 0).slice(-5)
      : ordered;
    const values = records.map((record) => Number(record.weight));
    const min = Math.min.apply(null, values);
    const max = Math.max.apply(null, values);
    const range = max - min || 1;
    this.setData({
      stats: [
        { label: "平均", value: (values.reduce((sum, value) => sum + value, 0) / values.length).toFixed(1), unit: "kg" },
        { label: "最低", value: min.toFixed(1), unit: "kg" },
        { label: "最高", value: max.toFixed(1), unit: "kg" }
      ],
      healthBars: sampled.map((record, index) => ({
        label: `${Number(record.date.slice(5, 7))}/${Number(record.date.slice(8, 10))}`,
        value: Number(record.weight).toFixed(1),
        height: Math.round(28 + (Number(record.weight) - min) / range * 64),
        accent: index === sampled.length - 1
      }))
    });
  },

  onTab(e) {
    const tab = e.currentTarget.dataset.key;
    if (tab !== this.data.tab) this.setData({ tab });
  }
});
